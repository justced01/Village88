$('img').click(function (){
    $( this ).hide(300);
})

$('button').click(function (){
    $('img').show();
})
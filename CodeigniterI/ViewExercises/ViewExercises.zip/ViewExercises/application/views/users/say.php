<?php for($index = 0; $index < $loop; $index++){ ?>
        <p><?= $message ?></p>
<?php } ?>


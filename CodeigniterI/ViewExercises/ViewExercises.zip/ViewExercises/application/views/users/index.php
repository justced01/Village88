<?php
    echo "Hello Users!";
?>
<p><a href="new">New page</a></p>
<p><a href="count">Count page</a></p>

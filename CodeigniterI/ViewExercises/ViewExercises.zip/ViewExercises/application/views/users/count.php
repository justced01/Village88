<?= "You visited this page " . $_SESSION['count'] . " times."; ?>


<a href="reset">Reset</a>
<a href="count">Count</a>
<p><a href="users">Index</a></p>
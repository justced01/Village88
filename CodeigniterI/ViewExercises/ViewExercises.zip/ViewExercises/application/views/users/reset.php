<p>Count has been reset.</p>
<a href="count">Back to count.</a>